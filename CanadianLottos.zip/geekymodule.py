from time import sleep
import random as r
import sys
from os import system, name

NUMPART = ''
LOTTOANSWER = 0
count = 0

def COLORSTRTER():
    print('\033[2;32;40m')
    clear()

def INTRO():
    print( "||>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<||")
    sleep(0.15)
    print(" ")
    sleep(0.15)
    print( "WELCOME TO A GEEK MADE PROGRAM")
    sleep(0.15)
    print( "By: Sebastian Gordon")
    sleep(0.15)
    print(" ")
    sleep(0.15)
    print( "||>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<||")
    print('\n')
    sleep(1)
    
def LOADING():

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [------------]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    clear()

    sleep(0.2)

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [❚-----------]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')

    sleep(0.2)
    clear()

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [❚❚----------]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')

    sleep(0.2)
    clear()

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [❚❚❚---------]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')

    sleep(0.2)
    clear()

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [❚❚❚❚--------]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')

    sleep(0.2)
    clear()

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [❚❚❚❚❚-------]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')

    sleep(0.2)
    clear()

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [❚❚❚❚❚❚------]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')

    sleep(0.2)
    clear()

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [❚❚❚❚❚❚❚-----]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')

    sleep(0.2)
    clear()

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [❚❚❚❚❚❚❚❚----]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')

    sleep(0.2)
    clear()

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [❚❚❚❚❚❚❚❚❚---]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')

    sleep(0.2)
    clear()

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [❚❚❚❚❚❚❚❚❚❚--]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')

    sleep(0.2)
    clear()

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [❚❚❚❚❚❚❚❚❚❚❚-]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')

    sleep(0.2)
    clear()

    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')
    print('Loading [❚❚❚❚❚❚❚❚❚❚❚❚]')
    print('\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\')

    sleep(0.4)
    clear()
    sleep(1)
    
def LMAXGEN(NUMPART,LOTTOANSWER,count):
#lottomax generator
    print('[LOTTO MAX PICKED]')
    sleep(1)
    LOADING()
    clear()
    while count != 5:
        Number = r.randint(1,50)
        NUMPART += ' '+str(Number)
        clear()
        count += 1
        print('[|||||||||||||||||||||||||||||||||||]')
        print('\n')
        print('LOTTO NUMBERS:')
        print(NUMPART)
        print('\n')
        print('[|||||||||||||||||||||||||||||||||||]')
        
def SFNGEN(NUMPART,LOTTOANSWER,count):
#lotto 649 generator
    print('[LOTTO SIX FORTY NINE PICKED]')
    sleep(1)
    LOADING()
    clear()
    while count != 6:
        Number = r.randint(1,49)
        NUMPART += ' '+str(Number)
        clear()
        count += 1
        print('[|||||||||||||||||||||||||||||||||||]')
        print('\n')
        print('LOTTO NUMBERS:')
        print(NUMPART)
        print('\n')
        print('[|||||||||||||||||||||||||||||||||||]')
        
def clear():
    if name == 'nt':
        _ = system('cls')
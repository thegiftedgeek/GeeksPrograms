from geekymodule import *
import sys

INTRO()

WCHLTTO = int(input('LOTTOMAX - 1'+'\n'+'LOTTO SIX FORTY NINE - 2'+'\n'+'\n'+'Which lotto would you like to generate numbers for?: '))

if WCHLTTO == 1:
    LMAXGEN(NUMPART,LOTTOANSWER,count)
    
elif WCHLTTO == 2:
    SFNGEN(NUMPART,LOTTOANSWER,count)
    
else:
    print('INCORRECT OPTION')
    exit()
